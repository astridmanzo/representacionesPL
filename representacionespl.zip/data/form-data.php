<?php exit(); /* For security reason. To avoid public user downloading below data! */?>
"RecordID"	"Date"	"IP"	"Nombre Completo"	"Email"	"Teléfono"	"Mensaje"
"20160401-17bb"	"2016-04-01 08:50:43"	"192.168.1.100"	"Astrid Manzo"	"astridmanzo@gmail.com"	"+584244522052"	"hello, world."
"20160401-894f"	"2016-04-01 11:08:53"	"192.168.1.100"	"Astrid Manzo"	"astridmanzo@gmail.com"	"+58424"	"hello,world"
"20160401-7ef0"	"2016-04-01 11:10:38"	"192.168.1.100"	"Astrid Manzo"	"astridmanzo@gmail.com"	"58"	"hello, world"
"20160401-8f33"	"2016-04-01 11:16:22"	"192.168.1.100"	"astrid manzo"	"astridmanzo@gmail.com"	"+584244522052"	"hello, world"
"20160401-6157"	"2016-04-01 11:25:23"	"192.168.1.100"	"astrid manzo"	"astridmanzo@gmail.com"	"3222323"	"hello"
"20160401-48d3"	"2016-04-01 11:27:46"	"192.168.1.100"	"astrid manzo"	"astridmanzo@gmail.com"	"2332323"	"helloooooooo"
