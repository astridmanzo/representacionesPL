<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 logo-footer">
				<a href="index.php"><img src="../logo.png"><h2>Representaciones PL</h2></a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 subfooter">
				<p>Sitio web desarrollado por: <a href="www.bluepolygon.com.ve"><br>Blue Polygon C,A.</a></p>
			</div>	
		</div>
	</div>
</footer>