<div class="container location-text">
	<div class="row">
		<div class="col-md-5 col-sm-12">		
			<div class="col-md-12 col-sm-12 location">
				<div class="row well">
					<span class="glyphicon glyphicon-map-marker"></span>		
					<p>Urb. Castillete, sector Los Jarales, calle principal manzana MCI, San Diego, Edo. Carabobo.</p>	
				</div>
			</div>
			<div class="col-md-12 col-sm-6">
				<div class="row well datos-mapa">
					<div class="col-md-12 col-sm-12">
						<p>Fax: 0241-8722912</p>
					</div>
					<div class="col-md-12 col-sm-12">
						<p>Teléfono: 0241-8720230</p>
					</div>
				</div>
			</div>
			<div class="col-md-12 col-sm-6">
				<div class="row well datos-mapa">
					<div class="col-md-12 col-sm-12">
						<p>Reprepl@cantv.net</p>
					</div>
					<div class="col-md-12 col-sm-12">
						<p>info@representacionespl.com.ve</p>
					</div>
				</div>
			</div>			
		</div>
		<div class="col-md-7 col-sm-12">
			<div class="embed-responsive embed-responsive-16by9 mapa">
			  <iframe src="https://www.google.com/maps/embed/v1/place?q=Representaciones%20PL&key=AIzaSyCI6kNIvGWAC1kvs0h4xQj3QHrqaLKrYBk" allowfullscreen></iframe>
			</div>
		</div>
	</div>
	
</div>
	

