<div class="container">
	<div class="my-slider slideshow">

		<ul>
			<li><img src="assets/slideshow/2.png" class="img-responsive"></li>
			<li><img src="assets/slideshow/3.png" class="img-responsive"></li>
			<li><img src="assets/slideshow/4.png" class="img-responsive"></li>
			<li><img src="assets/slideshow/5.png" class="img-responsive"></li>
			<li><img src="assets/slideshow/2.png" class="img-responsive"></li>
		</ul>

	</div>
</div>